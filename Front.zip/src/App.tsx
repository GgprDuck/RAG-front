/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { flushSync } from 'react-dom';
import axios from 'axios';

type UploadMode = 'knowledge' | 'images' | 'image-query' | 'all-images' | 'all-documents' | 'advanced-rag' | 'evaluation';
type RerankStrategy = 'llm_based' | 'cross_encoder' | 'none';
type ChunkingStrategy = 'simple' | 'semantic' | 'parent-child';

type ImageData = { id: string; s3Url: string; description?: string; score?: number; keywords?: string[] };
type DocumentData = { id: string; text: string; createdAt?: string; model?: string };
type Citation = { id: string; documentId: string; text: string };
type SourceDoc = { id: string; text: string; score?: number; metadata?: Record<string, any> };
type StreamMeta = {
  citations: Citation[]; images: string[]; confidence?: number; relevantChunks: number;
  queryType?: 'entity' | 'factual' | 'wide'; queryConfidence?: number; generationParams?: any; sources?: SourceDoc[];
};
type StreamChunkEvent =
  | { event: 'metadata';   metadata: Partial<StreamMeta> & { conversationContext?: boolean } }
  | { event: 'sources';    sources: SourceDoc[] }
  | { event: 'token';      token: string }
  | { event: 'citations';  citations: Citation[] }
  | { event: 'correction'; correctedAnswer: string; reason: 'hallucination' }
  | { event: 'done';       metadata: Partial<StreamMeta> }
  | { event: 'error';      error: string };

type ChatMessage = { role: 'user' | 'assistant'; content: string; meta?: StreamMeta | null; isCorrected?: boolean; timestamp: number };
type Chat = { sessionId: string; firstMessage: string; lastActivity: string | Date; turnCount: number; messages?: ChatMessage[] };
type Toast = { id: number; text: string; type: 'ok' | 'err' | 'info' };

const API = import.meta.env.VITE_API_URL;

// ── Helpers ──────────────────────────────────────────────────
const fmtTime = (ts: number) => new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const fmtDate = (d: string | Date) => {
  const date = new Date(d);
  const now = new Date();
  const diff = Math.floor((now.getTime() - date.getTime()) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  if (diff < 7)  return 'This week';
  return date.toLocaleDateString([], { month: 'short', year: 'numeric' });
};

// ── Toast system ──────────────────────────────────────────────
let toastId = 0;
const ToastContainer: React.FC<{ toasts: Toast[]; onRemove: (id: number) => void }> = ({ toasts, onRemove }) => (
  <div className="fixed bottom-6 right-6 flex flex-col gap-2 z-[9998] pointer-events-none">
    {toasts.map(t => (
      <div
        key={t.id}
        className={[
          'flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-mono text-xs pointer-events-auto min-w-[200px] max-w-[340px]',
          'shadow-[0_4px_20px_rgba(0,0,0,.35)] backdrop-blur-sm animate-[toastIn_.25s_ease_both]',
          t.type === 'ok'   ? 'bg-[rgba(92,200,138,.12)] border border-[rgba(92,200,138,.25)] text-[#5cc88a]' :
          t.type === 'err'  ? 'bg-[rgba(232,124,124,.12)] border border-[rgba(232,124,124,.25)] text-[#e87c7c]' :
                              'bg-[rgba(75,142,240,.12)] border border-[rgba(75,142,240,.25)] text-[#4b8ef0]',
        ].join(' ')}
      >
        <span>{t.type === 'ok' ? '✓' : t.type === 'err' ? '✗' : '·'}</span>
        <span className="flex-1">{t.text}</span>
        <span className="ml-auto opacity-60 hover:opacity-100 cursor-pointer text-xs px-0.5" onClick={() => onRemove(t.id)}>✕</span>
      </div>
    ))}
  </div>
);

// ── Skeleton loader ───────────────────────────────────────────
const SidebarSkeleton = () => (
  <div className="p-2 flex flex-col gap-1.5">
    {[80, 60, 90, 55, 70].map((w, i) => (
      <div key={i} className="flex items-center gap-2 px-1.5 py-2">
        <div
          className="h-3 rounded-md bg-gradient-to-r from-white/5 via-white/10 to-white/5 bg-[length:200%_100%] animate-[shimmer_1.4s_ease-in-out_infinite]"
          style={{ width: `${w}%` }}
        />
      </div>
    ))}
  </div>
);

// ── Empty state ───────────────────────────────────────────────
const EmptyChats = () => (
  <div className="flex flex-col items-center px-4 py-7 gap-2">
    <svg width="38" height="38" viewBox="0 0 38 38" fill="none" className="opacity-35">
      <rect x="3" y="7" width="32" height="22" rx="5" stroke="currentColor" strokeWidth="1.8" className="text-gray-400"/>
      <path d="M10 17h18M10 22h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" className="text-gray-400"/>
      <path d="M13 29l-4 5M25 29l4 5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" className="text-gray-400"/>
    </svg>
    <span className="font-sans text-xs text-[var(--dim)] text-center leading-relaxed">
      No chats yet.<br/>Start a new one!
    </span>
  </div>
);

// ── Toggle ────────────────────────────────────────────────────
const Toggle: React.FC<{ checked: boolean; onChange: (v: boolean) => void; label: string; sub?: string }> = ({ checked, onChange, label, sub }) => (
  <div
    onClick={() => onChange(!checked)}
    className="flex items-start gap-2.5 cursor-pointer select-none py-1"
  >
    <div
      className={[
        'flex-shrink-0 w-8 h-[18px] rounded-full border relative transition-all duration-200 mt-0.5',
        checked ? 'bg-[#4b8ef0] border-[#4b8ef0]' : 'bg-transparent border-[var(--border2)]',
      ].join(' ')}
    >
      <div
        className={[
          'absolute top-0.5 w-3 h-3 rounded-full transition-[left] duration-200',
          checked ? 'left-[16px] bg-white' : 'left-0.5 bg-[var(--border2)]',
        ].join(' ')}
      />
    </div>
    <div>
      <div className={`text-sm transition-colors duration-200 ${checked ? 'text-[var(--text)]' : 'text-[var(--muted)]'}`}>{label}</div>
      {sub && <div className="text-[0.66rem] text-[var(--dim)] mt-0.5 font-mono">{sub}</div>}
    </div>
  </div>
);

const Btn: React.FC<{ onClick: () => void; disabled?: boolean; danger?: boolean; children: React.ReactNode; accent?: boolean; style?: React.CSSProperties }> = ({ onClick, disabled, danger, children, accent, style }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    style={style}
    className={[
      'w-full py-2.5 px-5 rounded-lg font-sans font-medium text-sm transition-all duration-150',
      disabled        ? 'border border-[var(--border2)] bg-[var(--surface)] text-[var(--dim)] cursor-not-allowed' :
      danger          ? 'border border-[rgba(232,124,124,.25)] bg-[rgba(232,124,124,.08)] text-[#e87c7c] cursor-pointer' :
      accent          ? 'border border-[rgba(75,142,240,.4)] bg-[rgba(75,142,240,.09)] text-[#4b8ef0] cursor-pointer' :
                        'border border-[var(--border2)] bg-[var(--surface)] text-[var(--muted)] cursor-pointer',
    ].join(' ')}
  >{children}</button>
);

const RangeField: React.FC<{
  label: string; value: number | undefined; onChange: (v: number | undefined) => void;
  min: number; max: number; step: number; fmt?: (v: number) => string; placeholder?: string
}> = ({ label, value, onChange, min, max, step, fmt, placeholder = 'auto' }) => {
  const pct = value !== undefined ? ((value - min) / (max - min)) * 100 : 0;
  return (
    <div className="mb-3.5">
      <div className="flex justify-between mb-1.5">
        <span className="font-mono text-[0.6rem] tracking-[.1em] uppercase text-[var(--muted)]">{label}</span>
        <div className="flex gap-1.5 items-center">
          <span className={`font-mono text-[0.72rem] ${value !== undefined ? 'text-[#4b8ef0]' : 'text-[var(--dim)]'}`}>
            {value !== undefined ? (fmt ? fmt(value) : value) : placeholder}
          </span>
          {value !== undefined && (
            <span
              onClick={() => onChange(undefined)}
              className="font-mono text-[0.6rem] text-[var(--muted)] cursor-pointer px-1 border border-[var(--border2)] rounded-[3px]"
            >✕</span>
          )}
        </div>
      </div>
      <input
        type="range" min={min} max={max} step={step} value={value ?? min}
        style={{ '--pct': `${pct}%` } as any}
        onChange={e => onChange(parseFloat(e.target.value))}
        className="w-full h-0.5 rounded-sm cursor-pointer appearance-none
          [background:linear-gradient(90deg,#4b8ef0_var(--pct,0%),var(--border2)_var(--pct,0%))]
          [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3
          [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#4b8ef0] [&::-webkit-slider-thumb]:cursor-pointer
          [&::-webkit-slider-thumb]:shadow-[0_0_0_3px_rgba(75,142,240,.13)]"
      />
    </div>
  );
};

const Spin: React.FC<{ size?: number }> = ({ size = 12 }) => (
  <span
    style={{ width: size, height: size }}
    className="border-2 border-[var(--border2)] border-t-[#4b8ef0] rounded-full inline-block animate-spin flex-shrink-0"
  />
);

const SendButton: React.FC<{ active: boolean; isStreaming: boolean; onSend: () => void; onStop: () => void }> = ({ active, isStreaming, onSend, onStop }) => {
  const [firing, setFiring] = useState(false);
  const handleClick = () => {
    if (isStreaming) { onStop(); return; }
    if (!active) return;
    setFiring(true); setTimeout(() => setFiring(false), 420); onSend();
  };
  if (isStreaming) return (
    <button
      onClick={handleClick}
      title="Stop"
      className="w-9 h-9 rounded-[10px] flex items-center justify-center cursor-pointer flex-shrink-0 bg-[var(--surface2)] border border-[var(--border2)] hover:bg-[var(--border2)] transition-colors self-end"
    >
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
        <rect x="2.5" y="2.5" width="9" height="9" rx="2" fill="var(--muted)"/>
      </svg>
    </button>
  );
  return (
    <button
      onClick={handleClick}
      disabled={!active}
      title="Send (Enter)"
      className={[
        'w-9 h-9 rounded-[10px] border-none flex items-center justify-center flex-shrink-0 transition-all duration-150 self-end overflow-hidden',
        active
          ? 'bg-[#4b8ef0] cursor-pointer shadow-[0_2px_8px_rgba(75,142,240,.4)] hover:bg-[#3a7de0] hover:scale-105 hover:shadow-[0_4px_14px_rgba(75,142,240,.5)]'
          : 'bg-transparent cursor-not-allowed border border-[var(--border2)]',
        firing ? 'animate-[sendPop_.4s_cubic-bezier(.36,.07,.19,.97)_both]' : '',
      ].join(' ')}
    >
      <span
        className={[
          'font-[Material_Symbols_Outlined] not-italic text-[20px] leading-none select-none',
          firing ? 'animate-[arrowShoot_.4s_cubic-bezier(.36,.07,.19,.97)_both]' : '',
        ].join(' ')}
        style={{ color: active ? '#fff' : 'var(--dim)' }}
      >arrow_forward</span>
    </button>
  );
};

// ── ChatSidebar ────────────────────────────────────────────────
const ChatSidebar: React.FC<{
  chats: Chat[]; activeChatId: string | null;
  onSelect: (id: string) => void; onNew: () => void;
  onDelete: (id: string) => void; onRename: (id: string, name: string) => void;
  loading?: boolean;
}> = ({ chats, activeChatId, onSelect, onNew, onDelete, onRename, loading }) => {
  const [search, setSearch] = useState('');
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameVal, setRenameVal] = useState('');

  const filtered = search.trim()
    ? chats.filter(c => (c.firstMessage || '').toLowerCase().includes(search.toLowerCase()))
    : chats;

  const groups: { label: string; chats: Chat[] }[] = [];
  filtered.forEach(chat => {
    const label = fmtDate(chat.lastActivity);
    const g = groups.find(g => g.label === label);
    if (g) g.chats.push(chat);
    else groups.push({ label, chats: [chat] });
  });

  const startRename = (chat: Chat, e: React.MouseEvent) => {
    e.stopPropagation();
    setRenamingId(chat.sessionId);
    setRenameVal(chat.firstMessage || '');
  };
  const commitRename = (id: string) => {
    if (renameVal.trim()) onRename(id, renameVal.trim());
    setRenamingId(null);
  };

  return (
    <div className="w-[244px] bg-[var(--surface)] border-r border-[var(--border)] flex flex-col flex-shrink-0 h-full overflow-hidden">
      {/* Header */}
      <div className="px-2.5 pt-3 pb-2.5 border-b border-[var(--border)] flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#4b8ef0] flex items-center justify-center font-mono text-[0.58rem] font-bold text-white flex-shrink-0">R</div>
          <div>
            <div className="font-sans text-[0.84rem] font-bold text-[var(--text)]">RAG System</div>
            <div className="font-mono text-[0.52rem] text-[var(--dim)] tracking-[.08em]">knowledge base</div>
          </div>
        </div>
        <button
          onClick={onNew}
          className="w-full py-[0.45rem] rounded-lg border border-[rgba(75,142,240,.4)] bg-[rgba(75,142,240,.09)] text-[#4b8ef0] cursor-pointer font-sans text-[0.75rem] font-semibold flex items-center justify-center gap-1.5 transition-all duration-150 hover:bg-[#4b8ef0] hover:text-white"
        >
          <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
            <path d="M6 1v10M1 6h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
          </svg>
          New Chat
        </button>
        <input
          className="bg-[var(--surface2)] border border-[var(--border)] rounded-lg py-1.5 px-2.5 text-[0.78rem] font-sans text-[var(--text)] outline-none w-full transition-all duration-150 placeholder:text-[var(--dim)] resize-none leading-snug focus:border-[#4b8ef0] focus:shadow-[0_0_0_2px_rgba(75,142,240,.13)]"
          placeholder="Search chats…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* Chat list */}
      <div className="flex-1 overflow-y-auto py-1.5 px-2">
        {loading ? <SidebarSkeleton /> : filtered.length === 0 ? (
          search
            ? <div className="py-4 px-2.5 font-sans text-[0.74rem] text-[var(--dim)] text-center">No results</div>
            : <EmptyChats />
        ) : (
          groups.map(({ label, chats: groupChats }) => (
            <div key={label}>
              <div className="font-mono text-[0.6rem] tracking-[.1em] uppercase text-[var(--dim)] px-1.5 pt-2.5 pb-1">{label}</div>
              {groupChats.map(chat => (
                <div
                  key={chat.sessionId}
                  onClick={() => renamingId !== chat.sessionId && onSelect(chat.sessionId)}
                  onDoubleClick={e => startRename(chat, e)}
                  className={[
                    'px-2.5 py-[7px] cursor-pointer flex items-center gap-2 transition-[background] duration-150 border-l-2 rounded-lg mb-0.5 relative group',
                    activeChatId === chat.sessionId
                      ? 'bg-[rgba(75,142,240,.09)] border-l-[#4b8ef0]'
                      : 'border-l-transparent hover:bg-[var(--surface2)]',
                  ].join(' ')}
                >
                  {renamingId === chat.sessionId ? (
                    <input
                      className="flex-1 bg-[var(--surface)] border border-[#4b8ef0] rounded-[5px] text-[var(--text)] font-sans text-[0.78rem] py-0.5 px-1.5 outline-none min-w-0"
                      value={renameVal}
                      onChange={e => setRenameVal(e.target.value)}
                      onBlur={() => commitRename(chat.sessionId)}
                      onKeyDown={e => { if (e.key === 'Enter') commitRename(chat.sessionId); if (e.key === 'Escape') setRenamingId(null); }}
                      onClick={e => e.stopPropagation()}
                      autoFocus
                    />
                  ) : (
                    <div
                      title={chat.firstMessage}
                      className={[
                        'font-sans text-[0.78rem] overflow-hidden text-ellipsis whitespace-nowrap flex-1 min-w-0',
                        activeChatId === chat.sessionId ? 'text-[var(--text)] font-medium' : 'text-[var(--muted)]',
                      ].join(' ')}
                    >{chat.firstMessage || chat.sessionId.slice(0, 14)}</div>
                  )}
                  {renamingId !== chat.sessionId && (
                    <span
                      onClick={e => { e.stopPropagation(); onDelete(chat.sessionId); }}
                      className="opacity-0 group-hover:opacity-100 font-mono text-[0.65rem] text-[#e87c7c] cursor-pointer py-0.5 px-[5px] rounded border border-[rgba(232,124,124,.25)] bg-[rgba(232,124,124,.08)] flex-shrink-0 transition-opacity duration-150"
                    >✕</span>
                  )}
                </div>
              ))}
            </div>
          ))
        )}
      </div>

      <div className="px-3 py-2 border-t border-[var(--border)]">
        <div className="font-mono text-[0.58rem] text-[var(--dim)]">{chats.length} chat{chats.length !== 1 ? 's' : ''}</div>
      </div>
    </div>
  );
};

// ── Markdown renderer ─────────────────────────────────────────
const MarkdownText: React.FC<{ text: string }> = ({ text }) => {
  const render = (src: string): React.ReactNode[] => {
    const lines = src.split('\n'); const nodes: React.ReactNode[] = []; let i = 0;
    const inlineRender = (s: string, key: string): React.ReactNode => {
      const parts: React.ReactNode[] = []; let buf = ''; let j = 0; let k = 0;
      while (j < s.length) {
        if (s[j] === '`') { const end = s.indexOf('`', j + 1); if (end !== -1) { if (buf) { parts.push(<span key={k++}>{buf}</span>); buf = ''; } parts.push(<code key={k++} className="font-mono text-[0.82rem] bg-[var(--surface2)] border border-[var(--border2)] rounded-[5px] px-1.5 py-px text-[#4b8ef0]">{s.slice(j + 1, end)}</code>); j = end + 1; continue; } }
        if (s[j] === '*' && s[j + 1] === '*') { const end = s.indexOf('**', j + 2); if (end !== -1) { if (buf) { parts.push(<span key={k++}>{buf}</span>); buf = ''; } parts.push(<strong key={k++} className="font-bold text-[var(--text)]">{s.slice(j + 2, end)}</strong>); j = end + 2; continue; } }
        if (s[j] === '*' && s[j + 1] !== '*') { const end = s.indexOf('*', j + 1); if (end !== -1) { if (buf) { parts.push(<span key={k++}>{buf}</span>); buf = ''; } parts.push(<em key={k++} className="italic text-[var(--muted)]">{s.slice(j + 1, end)}</em>); j = end + 1; continue; } }
        if (s[j] === '[') { const te = s.indexOf(']', j + 1); if (te !== -1 && s[te + 1] === '(') { const ue = s.indexOf(')', te + 2); if (ue !== -1) { if (buf) { parts.push(<span key={k++}>{buf}</span>); buf = ''; } parts.push(<a key={k++} href={s.slice(te + 2, ue)} target="_blank" rel="noopener noreferrer" className="text-[#4b8ef0] underline underline-offset-[3px] decoration-[rgba(75,142,240,.35)] break-all transition-[text-decoration-color,opacity] duration-150 hover:decoration-[#4b8ef0] hover:opacity-80 cursor-pointer">{s.slice(j + 1, te)}</a>); j = ue + 1; continue; } } }
        if (s[j] === '<' && (s.slice(j + 1, j + 9) === 'https://' || s.slice(j + 1, j + 8) === 'http://')) { const ci = s.indexOf('>', j + 1); if (ci !== -1) { if (buf) { parts.push(<span key={k++}>{buf}</span>); buf = ''; } const href = s.slice(j + 1, ci); parts.push(<a key={k++} href={href} target="_blank" rel="noopener noreferrer" className="text-[#4b8ef0] underline underline-offset-[3px] decoration-[rgba(75,142,240,.35)] break-all transition-[text-decoration-color,opacity] duration-150 hover:decoration-[#4b8ef0] hover:opacity-80 cursor-pointer">{href}</a>); j = ci + 1; continue; } }
        if (s.slice(j, j + 8) === 'https://' || s.slice(j, j + 7) === 'http://') { if (buf) { parts.push(<span key={k++}>{buf}</span>); buf = ''; } let ue = j; while (ue < s.length && !/[\s,)>\]"']/.test(s[ue])) ue++; while (ue > j && /[.,!?;:]/.test(s[ue - 1])) ue--; const href = s.slice(j, ue); parts.push(<a key={k++} href={href} target="_blank" rel="noopener noreferrer" className="text-[#4b8ef0] underline underline-offset-[3px] decoration-[rgba(75,142,240,.35)] break-all transition-[text-decoration-color,opacity] duration-150 hover:decoration-[#4b8ef0] hover:opacity-80 cursor-pointer">{href}</a>); j = ue; continue; }
        buf += s[j++];
      }
      if (buf) parts.push(<span key={k++}>{buf}</span>);
      return <React.Fragment key={key}>{parts}</React.Fragment>;
    };
    while (i < lines.length) {
      const line = lines[i];
      if (line.trimStart().startsWith('```')) { const cl: string[] = []; i++; while (i < lines.length && !lines[i].trimStart().startsWith('```')) { cl.push(lines[i]); i++; } nodes.push(<pre key={i} className="bg-[var(--surface2)] border border-[var(--border)] rounded-[10px] p-3.5 my-2.5 overflow-x-auto"><code className="bg-transparent border-none p-0 text-[var(--text)] font-mono text-[0.82rem] leading-[1.7]">{cl.join('\n')}</code></pre>); i++; continue; }
      const h3 = line.match(/^###\s+(.+)/); const h2 = line.match(/^##\s+(.+)/); const h1 = line.match(/^#\s+(.+)/);
      if (h3) { nodes.push(<h3 key={i} className="text-[0.97rem] font-semibold text-[var(--text)] mt-3 mb-1 leading-snug first:mt-0">{inlineRender(h3[1], `h3-${i}`)}</h3>); i++; continue; }
      if (h2) { nodes.push(<h2 key={i} className="text-[1.1rem] font-bold text-[var(--text)] mt-4 mb-1.5 leading-snug first:mt-0">{inlineRender(h2[1], `h2-${i}`)}</h2>); i++; continue; }
      if (h1) { nodes.push(<h1 key={i} className="text-[1.35rem] font-bold text-[var(--text)] mt-4 mb-2 leading-tight first:mt-0">{inlineRender(h1[1], `h1-${i}`)}</h1>); i++; continue; }
      if (/^---+$/.test(line.trim())) { nodes.push(<hr key={i} className="border-none border-t border-[var(--border)] my-3.5" />); i++; continue; }
      if (line.startsWith('>')) { nodes.push(<blockquote key={i} className="border-l-[3px] border-l-[#4b8ef0] pl-3.5 py-1 my-2 text-[var(--muted)] italic">{inlineRender(line.replace(/^>\s?/, ''), `bq-${i}`)}</blockquote>); i++; continue; }
      if (/^[-*+]\s/.test(line)) { const items: React.ReactNode[] = []; while (i < lines.length && /^[-*+]\s/.test(lines[i])) { items.push(<li key={i} className="list-disc leading-[1.7]">{inlineRender(lines[i].replace(/^[-*+]\s/, ''), `li-${i}`)}</li>); i++; } nodes.push(<ul key={`ul-${i}`} className="pl-5 my-1.5 flex flex-col gap-[3px]">{items}</ul>); continue; }
      if (/^\d+\.\s/.test(line)) { const items: React.ReactNode[] = []; while (i < lines.length && /^\d+\.\s/.test(lines[i])) { items.push(<li key={i} className="list-decimal leading-[1.7]">{inlineRender(lines[i].replace(/^\d+\.\s/, ''), `oli-${i}`)}</li>); i++; } nodes.push(<ol key={`ol-${i}`} className="pl-5 my-1.5 flex flex-col gap-[3px]">{items}</ol>); continue; }
      if (line.trim() === '') { i++; continue; }
      nodes.push(<p key={i} className="my-1.5 first:mt-0">{inlineRender(line, `p-${i}`)}</p>); i++;
    }
    return nodes;
  };
  return <div className="font-sans text-[0.93rem] leading-[1.85] text-[var(--text)]">{render(text)}</div>;
};

// ── MessageBubble ─────────────────────────────────────────────
const MessageBubble: React.FC<{ msg: ChatMessage; onLightbox: (url: string) => void }> = ({ msg, onLightbox }) => {
  const [expandedSrc, setExpandedSrc] = useState(false);
  const isUser = msg.role === 'user';

  const tagClass = (color?: string) => [
    'inline-flex items-center gap-1 font-mono text-[0.6rem] tracking-[.05em] px-[7px] py-0.5 rounded border',
    color === 'green'  ? 'border-[rgba(92,200,138,.3)] text-[#5cc88a] bg-[rgba(92,200,138,.08)]' :
    color === 'orange' ? 'border-[rgba(75,142,240,.3)] text-[#4b8ef0] bg-[rgba(75,142,240,.09)]' :
    color === 'red'    ? 'border-[rgba(232,124,124,.3)] text-[#e87c7c] bg-[rgba(232,124,124,.08)]' :
    color === 'blue'   ? 'border-[rgba(75,142,240,.3)] text-[#4b8ef0] bg-[rgba(75,142,240,.09)]' :
                         'border-[var(--border2)] text-[var(--muted)]',
  ].join(' ');

  return (
    <div className={`flex flex-col animate-[fadeUp_.18s_ease_both] ${isUser ? 'items-end py-1' : 'items-start py-1'}`}>
      {!isUser && (
        <div className="w-7 h-7 rounded-lg bg-[#4b8ef0] flex items-center justify-center font-mono text-[0.58rem] font-bold text-white flex-shrink-0 mb-1.5">R</div>
      )}
      <div className={isUser
        ? 'max-w-[72%] bg-[rgba(75,142,240,.09)] border border-[rgba(75,142,240,.4)] rounded-[18px_18px_4px_18px] px-[18px] py-3 leading-[1.7]'
        : 'bg-transparent border-none py-1 px-0 max-w-[86%]'
      }>
        {isUser
          ? <div className="font-sans text-[0.93rem] leading-[1.85] text-[var(--text)] whitespace-pre-wrap">{msg.content}</div>
          : <MarkdownText text={msg.content} />
        }

        {/* Images */}
        {msg.meta?.images && msg.meta.images.length > 0 && (
          <div className="mt-3 pt-3 border-t border-[var(--border)]">
            <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Images ({msg.meta.images.length})</div>
            <div className="grid grid-cols-[repeat(auto-fill,minmax(140px,1fr))] gap-2 mt-2.5">
              {msg.meta.images.map((url, i) => (
                <div key={i} onClick={() => onLightbox(url)} className="rounded-lg overflow-hidden border border-[var(--border2)] cursor-pointer transition-[border-color,transform] duration-150 hover:border-[#4b8ef0] hover:scale-[1.02]">
                  <img src={url} alt={`img-${i}`} className="w-full h-[90px] object-cover block" onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Citations */}
        {msg.meta?.citations && msg.meta.citations.length > 0 && (
          <div className="mt-3 pt-3 border-t border-[var(--border)]">
            <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Citations ({msg.meta.citations.length})</div>
            <div className="flex flex-col gap-1.5">
              {msg.meta.citations.slice(0, 4).map((c, i) => (
                <div key={i} className="flex gap-2">
                  <span className="font-mono text-[0.62rem] text-[#4b8ef0] flex-shrink-0">[{i + 1}]</span>
                  <div className="font-mono text-[0.7rem] text-[var(--muted)] leading-relaxed">{c.text.slice(0, 120)}{c.text.length > 120 ? '…' : ''}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Sources */}
        {msg.meta?.sources && msg.meta.sources.length > 0 && (
          <div className="mt-3 pt-3 border-t border-[var(--border)]">
            <div className="flex justify-between items-center mb-2">
              <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)]">Sources ({msg.meta.sources.length})</div>
              <span onClick={() => setExpandedSrc(v => !v)} className="font-mono text-[0.6rem] text-[var(--muted)] cursor-pointer py-px px-[7px] border border-[var(--border2)] rounded">{expandedSrc ? 'collapse' : 'expand'}</span>
            </div>
            {expandedSrc && msg.meta.sources.map((src, i) => (
              <div key={i} className="bg-[var(--surface2)] border border-[var(--border)] rounded-lg p-2.5 mb-1.5">
                <div className="flex justify-between mb-1">
                  <span className="font-mono text-[0.58rem] text-[var(--muted)]">#{i + 1} · {src.id.slice(0, 8)}…</span>
                  {src.score !== undefined && <span className="font-mono text-[0.58rem] text-[var(--muted)]">{src.score.toFixed(3)}</span>}
                </div>
                <p className="font-mono text-[0.72rem] text-[var(--muted)] leading-relaxed m-0">{src.text.slice(0, 240)}{src.text.length > 240 ? '…' : ''}</p>
              </div>
            ))}
          </div>
        )}

        {/* Tags */}
        {(msg.isCorrected || msg.meta?.queryType || msg.meta?.confidence !== undefined || msg.meta?.relevantChunks !== undefined) && (
          <div className="flex gap-1 flex-wrap mt-2.5">
            {msg.isCorrected && <span className={tagClass('red')}>hallucination filtered</span>}
            {msg.meta?.queryType && <span className={tagClass(msg.meta.queryType === 'entity' ? 'blue' : msg.meta.queryType === 'wide' ? 'orange' : 'green')}>{msg.meta.queryType}</span>}
            {msg.meta?.confidence !== undefined && <span className={tagClass('green')}>{(msg.meta.confidence * 100).toFixed(0)}% conf</span>}
            {msg.meta?.relevantChunks !== undefined && <span className={tagClass()}>{msg.meta.relevantChunks} chunks</span>}
          </div>
        )}
      </div>
      <div className="font-mono text-[0.58rem] text-[var(--dim)] mt-[3px] text-right">{fmtTime(msg.timestamp)}</div>
    </div>
  );
};

// ── ChatInput ─────────────────────────────────────────────────
const ChatInput: React.FC<{
  question: string; setQuestion: (v: string) => void;
  onSend: () => void; onStop: () => void;
  isStreaming: boolean; hasMessages: boolean;
  textareaRef: React.RefObject<HTMLTextAreaElement>
}> = ({ question, setQuestion, onSend, onStop, isStreaming, hasMessages, textareaRef }) => {
  const handleKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (!isStreaming && question.trim()) onSend(); }
  };

  if (!hasMessages) return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-10 pointer-events-none animate-[fadeIn_.25s_ease]">
      <div className="pointer-events-auto w-[min(640px,92%)] flex flex-col items-center">
        <div className="text-center mb-6 animate-[fadeUp_.3s_ease_both]">
          <div className="w-[52px] h-[52px] rounded-[14px] bg-[#4b8ef0] flex items-center justify-center font-mono text-[1.1rem] font-bold text-white mx-auto mb-3.5 shadow-[0_8px_24px_rgba(75,142,240,.13)]">R</div>
          <div className="font-sans text-[1.35rem] font-bold text-[var(--text)] mb-1.5">RAG System</div>
          <div className="font-sans text-[0.88rem] text-[var(--muted)]">Ask anything about your knowledge base</div>
        </div>
        <div className="w-full flex items-end bg-[var(--surface)] border border-[var(--border2)] rounded-[18px] px-5 py-3.5 shadow-[0_4px_28px_rgba(0,0,0,.12)] focus-within:border-[#4b8ef0] focus-within:shadow-[0_0_0_3px_rgba(75,142,240,.09)] transition-all duration-200">
          <textarea
            ref={textareaRef}
            className="flex-1 resize-none min-h-[26px] max-h-[200px] overflow-y-auto leading-[1.6] bg-transparent border-none outline-none shadow-none text-[1rem] font-sans text-[var(--text)] placeholder:text-[var(--dim)] mb-[5px]"
            value={question}
            onChange={e => setQuestion(e.target.value)}
            onKeyDown={handleKey}
            placeholder="What would you like to know?"
            rows={1}
          />
          {isStreaming
            ? <button onClick={onStop} className="w-9 h-9 rounded-[10px] flex items-center justify-center cursor-pointer flex-shrink-0 bg-[var(--surface2)] border border-[var(--border2)] hover:bg-[var(--border2)] transition-colors self-end"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="2.5" y="2.5" width="9" height="9" rx="2" fill="var(--muted)"/></svg></button>
            : <SendButton active={!!question.trim()} isStreaming={false} onSend={onSend} onStop={onStop} />
          }
        </div>
        <div className="font-mono text-[0.6rem] text-[var(--dim)] mt-2 tracking-[.04em]">Enter to send · Shift+Enter for new line</div>
      </div>
    </div>
  );

  return (
    <div className="px-5 pt-2.5 pb-4 bg-[var(--bg)] flex-shrink-0">
      <div className="flex items-end bg-[var(--surface)] border border-[var(--border2)] rounded-[16px] px-2.5 py-2.5 pl-4 transition-[border-color,box-shadow] duration-200 focus-within:border-[#4b8ef0] focus-within:shadow-[0_0_0_3px_rgba(75,142,240,.09)]">
        <textarea
          ref={textareaRef}
          className="flex-1 resize-none min-h-[26px] max-h-[200px] overflow-y-auto leading-[1.6] bg-transparent border-none outline-none shadow-none text-[0.93rem] font-sans text-[var(--text)] placeholder:text-[var(--dim)] mb-1"
          value={question}
          onChange={e => setQuestion(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Message RAG System…"
          rows={1}
        />
        {isStreaming
          ? <button onClick={onStop} className="w-9 h-9 rounded-[10px] flex items-center justify-center cursor-pointer flex-shrink-0 bg-[var(--surface2)] border border-[var(--border2)] hover:bg-[var(--border2)] transition-colors self-end"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="2.5" y="2.5" width="9" height="9" rx="2" fill="var(--muted)"/></svg></button>
          : <SendButton active={!!question.trim()} isStreaming={false} onSend={onSend} onStop={onStop} />
        }
      </div>
      <div className="text-center font-mono text-[0.58rem] text-[var(--dim)] mt-[7px] tracking-[.04em]">Enter to send · Shift+Enter for new line</div>
    </div>
  );
};

// ── Main ──────────────────────────────────────────────────────
const RagDemo: React.FC = () => {
  const [mode, setMode] = useState<UploadMode>('advanced-rag');
  const [darkMode, setDarkMode] = useState(true);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [chatsLoading, setChatsLoading] = useState(true);

  const [streamText, setStreamText] = useState('');
  const [streamMeta, setStreamMeta] = useState<StreamMeta | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isCorrected, setIsCorrected] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const accumulatedRef = useRef('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [question, setQuestion] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [folderFiles, setFolderFiles] = useState<File[]>([]);
  const [images, setImages] = useState<File[]>([]);
  const [chunkingStrategy, setChunkingStrategy] = useState<ChunkingStrategy>('simple');
  const [enableKnowledgeGraph, setEnableKnowledgeGraph] = useState(false);
  const [busy, setBusy] = useState(false);

  const [useHybridSearch, setUseHybridSearch] = useState(true);
  const [useReranking, setUseReranking] = useState(true);
  const [rerankStrategy, setRerankStrategy] = useState<RerankStrategy>('none');
  const [useQueryTransformation, setUseQueryTransformation] = useState(true);
  const [useContextualCompression, setUseContextualCompression] = useState(false);
  const [useConversationMemory, setUseConversationMemory] = useState(true);
  const [useCitationTracking, setUseCitationTracking] = useState(true);
  const [useKnowledgeGraph, setUseKnowledgeGraph] = useState(false);
  const [includeSources, setIncludeSources] = useState(false);
  const [limit, setLimit] = useState<number | undefined>(undefined);
  const [scoreThreshold, setScoreThreshold] = useState<number | undefined>(undefined);
  const [temperature, setTemperature] = useState<number | undefined>(undefined);
  const [topP, setTopP] = useState<number | undefined>(undefined);
  const [topK, setTopK] = useState<number | undefined>(undefined);
  const [maxTokens, setMaxTokens] = useState<number | undefined>(undefined);

  const [sessionId] = useState(`session_${Date.now()}`);
  const [retrievedImages, setRetrievedImages] = useState<ImageData[]>([]);
  const [allDocuments, setAllDocuments] = useState<DocumentData[]>([]);
  const [evalResults, setEvalResults] = useState<any>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [lightboxImg, setLightboxImg] = useState<string | null>(null);

  // ── CSS Variables injected via style tag ──────────────────────
  const cssVars = darkMode ? `
    :root {
      --bg: #111111; --surface: #1a1a1a; --surface2: #222222;
      --border: #272727; --border2: #353535;
      --text: #ffffff; --muted: #999999; --dim: #444444;
      --accent: #4b8ef0; --accent-h: #3a7de0;
      --accent-bg: rgba(75,142,240,.13); --accent-bd: rgba(75,142,240,.35);
      --red: #e87c7c; --green: #5cc88a;
    }
  ` : `
    :root {
      --bg: #f7f7f7; --surface: #ffffff; --surface2: #f0f0f0;
      --border: #e2e2e2; --border2: #cecece;
      --text: #0a0a0a; --muted: #5a5a5a; --dim: #b0b0b0;
      --accent: #4b8ef0; --accent-h: #3a7de0;
      --accent-bg: rgba(75,142,240,.09); --accent-bd: rgba(75,142,240,.4);
      --red: #e87c7c; --green: #5cc88a;
    }
  `;

  const globalStyles = `
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;700&family=DM+Sans:wght@300;400;500;600&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0');
    body { background: var(--bg); color: var(--text); font-family: 'DM Sans', sans-serif; }
    * { font-family: inherit; box-sizing: border-box; }
    .font-mono { font-family: 'JetBrains Mono', monospace !important; }
    ::-webkit-scrollbar { width: 4px; height: 4px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 4px; }
    textarea, input[type=text], input[type=file] { font-family: 'DM Sans', sans-serif; }
    select { font-family: 'JetBrains Mono', monospace; background: var(--surface); border: 1px solid var(--border2); color: var(--text); border-radius: 10px; padding: .55rem .8rem; font-size: .82rem; outline: none; width: 100%; cursor: pointer; }

    @keyframes spin      { to { transform: rotate(360deg); } }
    @keyframes blink     { 0%,100%{opacity:1} 50%{opacity:0} }
    @keyframes fadeUp    { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
    @keyframes fadeIn    { from{opacity:0} to{opacity:1} }
    @keyframes tabFade   { from{opacity:0;transform:translateY(4px)} to{opacity:1;transform:translateY(0)} }
    @keyframes toastIn   { from{opacity:0;transform:translateX(20px)} to{opacity:1;transform:translateX(0)} }
    @keyframes shimmer   { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
    @keyframes sendPop   { 0%{transform:scale(1)} 30%{transform:scale(.88) rotate(-8deg)} 65%{transform:scale(1.12) rotate(4deg)} 100%{transform:scale(1) rotate(0deg)} }
    @keyframes arrowShoot{ 0%{transform:translateX(0);opacity:1} 40%{transform:translateX(6px);opacity:0} 41%{transform:translateX(-6px);opacity:0} 100%{transform:translateX(0);opacity:1} }
    @keyframes dotPulse  { 0%,80%,100%{opacity:.25;transform:scale(.75)} 40%{opacity:1;transform:scale(1)} }
    @keyframes scrollBounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(3px)} }
    .streaming-cursor { display:inline-block; width:2px; height:1em; background:var(--accent); margin-left:2px; animation:blink .6s step-end infinite; vertical-align:text-bottom; border-radius:1px; }
    .tab-content { animation: tabFade .22s ease both; }
  `;

  // ── Toast helpers ─────────────────────────────────────────────
  const addToast = useCallback((text: string, type: Toast['type']) => {
    const id = ++toastId;
    setToasts(prev => [...prev, { id, text, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 4000);
  }, []);
  const ok  = useCallback((t: string) => addToast(t, 'ok'),   [addToast]);
  const err = useCallback((t: string) => addToast(t, 'err'),  [addToast]);
  const inf = useCallback((t: string) => addToast(t, 'info'), [addToast]);
  const removeToast = (id: number) => setToasts(prev => prev.filter(t => t.id !== id));

  const activeChat  = chats.find(c => c.sessionId === activeChatId) ?? null;
  const hasMessages = (activeChat?.messages?.length ?? 0) > 0 || isStreaming;

  useEffect(() => {
    const el = messagesContainerRef.current;
    if (!el) return;
    const handler = () => {
      const distFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
      setShowScrollBtn(distFromBottom > 120);
    };
    el.addEventListener('scroll', handler);
    return () => el.removeEventListener('scroll', handler);
  }, []);

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

  const fetchChats = useCallback(async () => {
    try { setChatsLoading(true); const r = await axios.get(`${API}/rag/chats`); setChats(r.data.data ?? []); }
    catch { /* silent */ } finally { setChatsLoading(false); }
  }, []);
  useEffect(() => { fetchChats(); }, [fetchChats]);
  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, [streamText, activeChat?.messages?.length]);
  useEffect(() => {
    if (textareaRef.current) { textareaRef.current.style.height = 'auto'; textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 200) + 'px'; }
  }, [question]);

  const changeMode = (newMode: UploadMode) => setMode(newMode);

  const createNewChat = useCallback(() => {
    const sid = `session_${Date.now()}`;
    setChats(prev => [{ sessionId: sid, firstMessage: 'New Chat', lastActivity: new Date(), turnCount: 0, messages: [] }, ...prev]);
    setActiveChatId(sid); setQuestion(''); setStreamText(''); setStreamMeta(null); setIsCorrected(false);
    if (mode !== 'advanced-rag') changeMode('advanced-rag');
    setTimeout(() => textareaRef.current?.focus(), 80);
  }, [mode]);

  const deleteChat = useCallback(async (sid: string) => {
    try {
      await axios.delete(`${API}/rag/chats/${sid}`);
      setChats(prev => { const next = prev.filter(c => c.sessionId !== sid); if (activeChatId === sid) setActiveChatId(next.length ? next[0].sessionId : null); return next; });
    } catch (e: any) { err(e.message); }
  }, [activeChatId]);

  const renameChat = useCallback((sid: string, name: string) => {
    setChats(prev => prev.map(c => c.sessionId === sid ? { ...c, firstMessage: name } : c));
  }, []);

  const selectChat = useCallback(async (sid: string) => {
    setActiveChatId(sid); setStreamText(''); setStreamMeta(null); setIsCorrected(false);
    if (mode !== 'advanced-rag') changeMode('advanced-rag');
    try {
      const r = await axios.get(`${API}/rag/chats/${sid}`);
      const { turns } = r.data.data as { sessionId: string; turns: Array<{ id: string; query: string; answer: string; timestamp: string }> };
      const messages: ChatMessage[] = [];
      for (const t of turns) {
        const ts = t.timestamp ? new Date(t.timestamp).getTime() : Date.now();
        messages.push({ role: 'user', content: t.query, timestamp: ts });
        messages.push({ role: 'assistant', content: t.answer, timestamp: ts + 1 });
      }
      setChats(prev => prev.map(c => c.sessionId === sid ? { ...c, messages } : c));
    } catch {}
  }, [mode]);

  const conversationHistory = (activeChat?.messages ?? []).map(m => ({ role: m.role, content: m.content }));

  const handleAsk = useCallback(async () => {
    if (!question.trim() || isStreaming) return;
    let chatId = activeChatId;
    if (!chatId) {
      const sid = `session_${Date.now()}`;
      setChats(prev => [{ sessionId: sid, firstMessage: question.trim().slice(0, 60), lastActivity: new Date(), turnCount: 0, messages: [] }, ...prev]);
      setActiveChatId(sid); chatId = sid;
    }
    const userMsg: ChatMessage = { role: 'user', content: question.trim(), timestamp: Date.now() };
    setChats(prev => prev.map(c => c.sessionId === chatId ? { ...c, messages: [...(c.messages ?? []), userMsg] } : c));
    const q = question.trim(); setQuestion('');
    abortRef.current?.abort();
    const ctrl = new AbortController(); abortRef.current = ctrl; accumulatedRef.current = '';
    flushSync(() => { setStreamText(''); setStreamMeta(null); setIsCorrected(false); setIsStreaming(true); });

    const body = {
      question: q, rerankStrategy, includeSources: true, limit, scoreThreshold, temperature, topP, topK, maxTokens,
      conversationHistory: useConversationMemory ? conversationHistory : undefined,
      options: { useHybridSearch, useReranking, useQueryTransformation, useContextualCompression, useConversationMemory, sessionId: chatId, useCitationTracking, useKnowledgeGraph },
    };
    let finalMeta: StreamMeta | null = null; let finalCorrected = false;
    try {
      const res = await fetch(`${API}/rag/documents/ask/stream`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: ctrl.signal });
      if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
      const reader = res.body.getReader(); const decoder = new TextDecoder(); let tail = '';
      const dispatch = (chunk: StreamChunkEvent) => {
        switch (chunk.event) {
          case 'metadata': setStreamMeta(prev => { const n = { images: [], citations: prev?.citations ?? [], sources: prev?.sources, relevantChunks: prev?.relevantChunks ?? 0, ...chunk.metadata } as StreamMeta; finalMeta = n; return n; }); break;
          case 'sources':  setStreamMeta(prev => { const n = { ...(prev ?? { images: [], citations: [], relevantChunks: 0 }), sources: chunk.sources } as StreamMeta; finalMeta = n; return n; }); break;
          case 'token': accumulatedRef.current += chunk.token; flushSync(() => setStreamText(accumulatedRef.current)); break;
          case 'correction': accumulatedRef.current = chunk.correctedAnswer; finalCorrected = true; flushSync(() => { setStreamText(chunk.correctedAnswer); setIsCorrected(true); }); break;
          case 'citations': setStreamMeta(prev => { const n = { ...(prev ?? { images: [], citations: [], relevantChunks: 0 }), citations: chunk.citations } as StreamMeta; finalMeta = n; return n; }); break;
          case 'done': setStreamMeta(prev => { const n = { images: [], citations: prev?.citations ?? [], sources: prev?.sources, relevantChunks: prev?.relevantChunks ?? 0, ...chunk.metadata } as StreamMeta; finalMeta = n; return n; }); break;
          case 'error': flushSync(() => setStreamText(`⚠ ${chunk.error}`)); break;
        }
      };
      while (true) {
        const { done, value } = await reader.read(); if (done) break;
        tail += decoder.decode(value, { stream: true });
        const msgs = tail.split('\n\n'); tail = msgs.pop() ?? '';
        for (const msg of msgs) {
          if (!msg.trim()) continue; let d = '';
          for (const line of msg.split('\n')) { if (line.startsWith('data: ')) d += line.slice(6); }
          if (!d.trim()) continue;
          try { dispatch(JSON.parse(d) as StreamChunkEvent); } catch {}
        }
      }
    } catch (e: any) { if (e.name !== 'AbortError') flushSync(() => setStreamText(`⚠ Stream error: ${e.message}`)); }
    finally {
      const fc = accumulatedRef.current;
      if (fc) {
        setChats(prev => prev.map(c => c.sessionId === chatId ? { ...c, messages: [...(c.messages ?? []), { role: 'assistant', content: fc, meta: finalMeta, isCorrected: finalCorrected, timestamp: Date.now() }] } : c));
        setChats(prev => prev.map(c => c.sessionId === chatId ? { ...c, turnCount: (c.turnCount ?? 0) + 1, firstMessage: q.slice(0, 60), lastActivity: new Date() } : c));
      }
      setStreamText(''); setStreamMeta(null); setIsStreaming(false);
    }
  }, [question, isStreaming, rerankStrategy, limit, scoreThreshold, temperature, topP, topK, maxTokens,
      conversationHistory, useHybridSearch, useReranking, useQueryTransformation, useContextualCompression,
      useConversationMemory, sessionId, useCitationTracking, useKnowledgeGraph, activeChatId]);

  const handleStopStream = () => { abortRef.current?.abort(); setIsStreaming(false); };

  const handleUploadKnowledge = async () => {
    if (!file) return err('Choose a file.');
    const fd = new FormData(); fd.append('file', file); fd.append('chunkingStrategy', chunkingStrategy); fd.append('enableKnowledgeGraph', enableKnowledgeGraph.toString());
    try { setBusy(true); inf('Uploading…'); const r = await axios.post(`${API}/rag/documents/upload`, fd); ok(`${r.data.data?.chunks || 0} chunks · ${chunkingStrategy}`); setFile(null); }
    catch (e: any) { err(e.response?.data?.message || e.message); } finally { setBusy(false); }
  };
  const handleUploadFolder = async () => {
    if (!folderFiles.length) return err('No markdown files selected.');
    const fd = new FormData(); folderFiles.forEach(f => fd.append('files', f)); fd.append('chunkingStrategy', chunkingStrategy); fd.append('enableKnowledgeGraph', enableKnowledgeGraph.toString());
    try { setBusy(true); inf('Uploading folder…'); const r = await axios.post(`${API}/rag/documents/upload-folder`, fd); ok(`${r.data.data.filesProcessed} files → ${r.data.data.totalChunks} chunks`); setFolderFiles([]); }
    catch (e: any) { err(e.response?.data?.message || e.message); } finally { setBusy(false); }
  };
  const handleUploadImages = async () => {
    if (!images.length) return err('Choose images.');
    const fd = new FormData(); images.forEach(img => fd.append('images', img));
    try { setBusy(true); inf('Uploading…'); const r = await axios.post(`${API}/rag/images/upload`, fd); ok(`${r.data.data?.imagesUploaded || 0} uploaded`); setImages([]); if (r.data.data?.generatedImage) setGeneratedImage(`data:image/png;base64,${r.data.data.generatedImage}`); }
    catch (e: any) { err(e.response?.data?.message || e.message); } finally { setBusy(false); }
  };
  const handleImageSearch = async () => {
    if (!question.trim()) return;
    try { setBusy(true); inf('Searching…'); const r = await axios.get(`${API}/rag/images/search`, { params: { query: question, limit: 10 } }); setRetrievedImages(r.data.data); ok(`${r.data.data.length} result(s)`); }
    catch (e: any) { err(e.message); } finally { setBusy(false); }
  };
  const handleRetrieveAllImages = async () => {
    try { setBusy(true); const r = await axios.get(`${API}/rag/images`); setRetrievedImages(r.data.data); ok(`${r.data.data.length} image(s)`); }
    catch (e: any) { err(e.message); } finally { setBusy(false); }
  };
  const handleRetrieveAllDocuments = async () => {
    try { setBusy(true); const r = await axios.get(`${API}/rag/documents`); setAllDocuments(r.data.data); ok(`${r.data.data.length} doc(s)`); }
    catch (e: any) { err(e.message); } finally { setBusy(false); }
  };
  const handleDeleteImage = async (id: string) => {
    try { setBusy(true); await axios.delete(`${API}/rag/images/${id}`); setRetrievedImages(p => p.filter(i => i.id !== id)); ok('Deleted'); }
    catch (e: any) { err(e.message); } finally { setBusy(false); }
  };
  const handleDeleteDoc = async (id: string) => {
    try { setBusy(true); await axios.delete(`${API}/rag/documents/${id}`); setAllDocuments(p => p.filter(d => d.id !== id)); ok('Deleted'); }
    catch (e: any) { err(e.message); } finally { setBusy(false); }
  };
  const handleEvaluate = async () => {
    if (!question.trim()) return err('Enter queries');
    try { setBusy(true); inf('Evaluating…'); const queries = question.split('\n').filter(q => q.trim()).map(q => ({ query: q.trim() })); const r = await axios.post(`${API}/rag/documents/evaluate`, { testQueries: queries }); setEvalResults(r.data.data); ok('Done'); }
    catch (e: any) { err(e.message); } finally { setBusy(false); }
  };

  useEffect(() => {
    if (mode === 'all-images')    handleRetrieveAllImages();
    if (mode === 'all-documents') handleRetrieveAllDocuments();
  }, [mode]);

  // ── Tag helper ────────────────────────────────────────────────
  const tagClass = (color?: string) => [
    'inline-flex items-center gap-1 font-mono text-[0.6rem] tracking-[.05em] px-[7px] py-0.5 rounded border',
    color === 'green'  ? 'border-[rgba(92,200,138,.3)] text-[#5cc88a] bg-[rgba(92,200,138,.08)]' :
    color === 'orange' ? 'border-[rgba(75,142,240,.3)] text-[#4b8ef0] bg-[rgba(75,142,240,.09)]' :
    color === 'red'    ? 'border-[rgba(232,124,124,.3)] text-[#e87c7c] bg-[rgba(232,124,124,.08)]' :
    color === 'blue'   ? 'border-[rgba(75,142,240,.3)] text-[#4b8ef0] bg-[rgba(75,142,240,.09)]' :
                         'border-[var(--border2)] text-[var(--muted)]',
  ].join(' ');

  // ── Pipeline panel ────────────────────────────────────────────
  const renderPipelinePanel = () => (
    <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-[18px]">
      <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Pipeline</div>
      <div className="grid grid-cols-2 gap-x-4 gap-y-0.5">
        <Toggle checked={useHybridSearch}         onChange={setUseHybridSearch}         label="Hybrid Search"   sub="Vector + BM25" />
        <Toggle checked={useQueryTransformation}   onChange={setUseQueryTransformation}   label="Query Expansion" sub="Rephrase + expand" />
        <Toggle checked={useContextualCompression} onChange={setUseContextualCompression} label="Compression"     sub="Extract relevant" />
        <Toggle checked={useCitationTracking}      onChange={setUseCitationTracking}      label="Citations"       sub="Track sources" />
        <Toggle checked={useConversationMemory}    onChange={setUseConversationMemory}    label="Memory"          sub="Session history" />
        <Toggle checked={useKnowledgeGraph}        onChange={setUseKnowledgeGraph}        label="Knowledge Graph" sub="Neo4j enrichment" />
        <Toggle checked={includeSources}           onChange={setIncludeSources}           label="Return Sources"  sub="Attach chunks" />
      </div>
      <div className="border-t border-[var(--border)] mt-3.5 pt-3.5">
        <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Re-ranking</div>
        <Toggle checked={useReranking} onChange={setUseReranking} label="Enable Re-ranking" />
        {useReranking && (
          <div className="mt-2.5">
            <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Strategy</div>
            <select value={rerankStrategy} onChange={e => setRerankStrategy(e.target.value as RerankStrategy)}>
              <option value="none">Hybrid (default)</option>
              <option value="cross_encoder">Cross-encoder (listwise)</option>
              <option value="llm_based">LLM-based</option>
            </select>
          </div>
        )}
      </div>
      <div className="border-t border-[var(--border)] mt-3.5 pt-3.5">
        <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Retrieval</div>
        <RangeField label="Chunks"          value={limit}          onChange={setLimit}          min={1}   max={20}   step={1}    placeholder="6" />
        <RangeField label="Score threshold" value={scoreThreshold} onChange={setScoreThreshold} min={0}   max={1}    step={0.05} fmt={v => v.toFixed(2)} placeholder="off" />
      </div>
      <div className="border-t border-[var(--border)] mt-3.5 pt-3.5">
        <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">LLM Generation</div>
        <RangeField label="Temperature" value={temperature} onChange={setTemperature} min={0}   max={1}    step={0.05} fmt={v => v.toFixed(2)} placeholder="auto" />
        <RangeField label="Top-p"       value={topP}        onChange={setTopP}        min={0}   max={1}    step={0.05} fmt={v => v.toFixed(2)} />
        <RangeField label="Top-k"       value={topK}        onChange={setTopK}        min={1}   max={100}  step={1} />
        <RangeField label="Max tokens"  value={maxTokens}   onChange={setMaxTokens}   min={100} max={8192} step={100} placeholder="auto" />
      </div>
    </div>
  );

  const TABS: { id: UploadMode; label: string }[] = [
    { id: 'advanced-rag',  label: 'Chat'        },
    { id: 'knowledge',     label: 'Knowledge'   },
    { id: 'images',        label: 'Images'      },
    { id: 'image-query',   label: 'Image Query' },
    { id: 'all-images',    label: 'All Images'  },
    { id: 'all-documents', label: 'All Docs'    },
    { id: 'evaluation',    label: 'Evaluation'  },
  ];

  return (
    <>
      <style>{cssVars + globalStyles}</style>

      {/* Toasts */}
      <ToastContainer toasts={toasts} onRemove={removeToast} />

      {/* Lightbox */}
      {lightboxImg && (
        <div
          onClick={() => setLightboxImg(null)}
          className="fixed inset-0 bg-black/90 flex items-center justify-center z-[9999] cursor-zoom-out backdrop-blur-sm"
        >
          <img
            src={lightboxImg} alt=""
            className="max-w-[90vw] max-h-[85vh] rounded-xl shadow-[0_0_80px_rgba(0,0,0,.8)]"
            onClick={e => e.stopPropagation()}
          />
          <span
            onClick={() => setLightboxImg(null)}
            className="absolute top-5 right-6 text-[1.2rem] text-[#888] cursor-pointer"
          >✕</span>
        </div>
      )}

      <div className="h-screen w-screen bg-[var(--bg)] text-[var(--text)] flex flex-col overflow-hidden">

        {/* ── Nav ── */}
        <nav className="h-[46px] bg-[var(--surface)] border-b border-[var(--border)] flex items-center px-4 gap-0 flex-shrink-0 overflow-x-auto sticky top-0 z-50">
          <div className="flex items-center gap-2 pr-4 border-r border-[var(--border)] mr-1 flex-shrink-0">
            <div className="w-6 h-6 rounded-[7px] bg-[#4b8ef0] flex items-center justify-center font-mono text-[0.58rem] font-bold text-white">R</div>
            <span className="font-sans text-[0.85rem] font-bold text-[var(--text)]">RAG</span>
          </div>
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => changeMode(tab.id)}
              className={[
                'bg-transparent border-none border-b-2 cursor-pointer px-3 h-[46px] font-sans text-[0.82rem] whitespace-nowrap transition-[color,border-color] duration-150 flex items-center',
                mode === tab.id
                  ? 'text-[#4b8ef0] border-b-[#4b8ef0] font-semibold'
                  : 'text-[var(--muted)] border-b-transparent font-normal hover:text-[var(--text)]',
              ].join(' ')}
            >{tab.label}</button>
          ))}
          <div className="ml-auto flex items-center gap-2 flex-shrink-0">
            {isStreaming && (
              <span className={tagClass('blue')}>
                <Spin size={7} /> live
              </span>
            )}
            <button
              onClick={() => setDarkMode(d => !d)}
              title="Toggle theme"
              className="w-8 h-8 rounded-lg border border-[var(--border2)] bg-[var(--surface2)] text-[var(--muted)] cursor-pointer flex items-center justify-center text-[0.9rem] transition-all duration-150 hover:border-[#4b8ef0] hover:text-[#4b8ef0]"
            >{darkMode ? '☀' : '☾'}</button>
          </div>
        </nav>

        {/* ── Chat tab ── */}
        {mode === 'advanced-rag' && (
          <div className="flex-1 flex overflow-hidden">
            <ChatSidebar chats={chats} activeChatId={activeChatId} onSelect={selectChat} onNew={createNewChat} onDelete={deleteChat} onRename={renameChat} loading={chatsLoading} />
            <div className="flex-1 flex flex-col overflow-hidden relative">
              {/* Messages */}
              <div ref={messagesContainerRef} className="flex-1 overflow-y-auto flex flex-col px-8 py-5">
                {hasMessages && <>
                  {(activeChat?.messages ?? []).map((msg, i) => (
                    <MessageBubble key={i} msg={msg} onLightbox={setLightboxImg} />
                  ))}
                  {isStreaming && streamText && (
                    <div className="flex flex-col items-start py-1 animate-[fadeUp_.18s_ease_both]">
                      <div className="w-7 h-7 rounded-lg bg-[#4b8ef0] flex items-center justify-center font-mono text-[0.58rem] font-bold text-white flex-shrink-0 mb-1.5">R</div>
                      <div className="bg-transparent border-none py-1 px-0 max-w-[86%]">
                        <div className="font-sans text-[0.93rem] leading-[1.85] text-[var(--text)]">
                          <MarkdownText text={streamText} />
                          <span className="streaming-cursor" />
                        </div>
                        <div className="flex gap-1 mt-2">
                          {isCorrected && <span className={tagClass('red')}>hallucination filtered</span>}
                          {streamMeta?.queryType && <span className={tagClass(streamMeta.queryType === 'entity' ? 'blue' : streamMeta.queryType === 'wide' ? 'orange' : 'green')}>{streamMeta.queryType}</span>}
                          {streamMeta?.confidence !== undefined && <span className={tagClass('green')}>{(streamMeta.confidence * 100).toFixed(0)}% conf</span>}
                          {streamMeta?.relevantChunks !== undefined && <span className={tagClass()}>{streamMeta.relevantChunks} chunks</span>}
                        </div>
                      </div>
                    </div>
                  )}
                  {isStreaming && !streamText && (
                    <div className="flex flex-col items-start py-1 animate-[fadeUp_.18s_ease_both]">
                      <div className="w-7 h-7 rounded-lg bg-[#4b8ef0] flex items-center justify-center font-mono text-[0.58rem] font-bold text-white flex-shrink-0 mb-1.5">R</div>
                      <div className="bg-transparent border-none py-1 px-0">
                        <div className="flex gap-1.5 py-2 items-center">
                          {[0, 1, 2].map(i => (
                            <span
                              key={i}
                              className="w-[7px] h-[7px] rounded-full bg-[var(--muted)] inline-block"
                              style={{ animation: `dotPulse 1.2s ${i * 0.2}s ease-in-out infinite` }}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </>}
              </div>

              {/* Scroll to bottom button */}
              {showScrollBtn && hasMessages && (
                <button
                  onClick={scrollToBottom}
                  title="Scroll to bottom"
                  className="absolute bottom-[110px] right-6 w-9 h-9 rounded-full bg-[var(--surface)] border border-[var(--border2)] text-[var(--muted)] cursor-pointer flex items-center justify-center shadow-[0_4px_12px_rgba(0,0,0,.3)] transition-[border-color,color,box-shadow] duration-150 z-[5] animate-[scrollBounce_1.8s_ease-in-out_infinite] hover:border-[#4b8ef0] hover:text-[#4b8ef0] hover:shadow-[0_4px_16px_rgba(75,142,240,.3)] hover:[animation:none] hover:-translate-y-0.5"
                >
                  <span className="font-[Material_Symbols_Outlined] not-italic text-[20px] leading-none select-none">arrow_downward</span>
                </button>
              )}

              <ChatInput
                question={question} setQuestion={setQuestion}
                onSend={handleAsk} onStop={handleStopStream}
                isStreaming={isStreaming} hasMessages={hasMessages}
                textareaRef={textareaRef}
              />
            </div>
          </div>
        )}

        {/* ── Other tabs ── */}
        {mode !== 'advanced-rag' && (
          <main
            key={mode}
            className="tab-content flex-1 overflow-auto p-5 px-7 max-w-[1140px] w-full mx-auto self-stretch box-border"
          >

            {/* Knowledge */}
            {mode === 'knowledge' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-3.5">
                  <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-[18px]">
                    <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Chunking Strategy</div>
                    <select value={chunkingStrategy} onChange={e => setChunkingStrategy(e.target.value as ChunkingStrategy)} className="mb-3">
                      <option value="simple">Simple — sentences</option>
                      <option value="semantic">Semantic — AI embeddings</option>
                      <option value="parent-child">Parent-Child — hierarchical</option>
                    </select>
                    <Toggle checked={enableKnowledgeGraph} onChange={setEnableKnowledgeGraph} label="Extract Knowledge Graph" sub="Build Neo4j entity graph" />
                  </div>
                  <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-[18px]">
                    <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Single File</div>
                    <input type="file" accept=".docx,.pdf,.txt,.md" onChange={e => { if (e.target.files?.[0]) setFile(e.target.files[0]); }} className="font-mono text-[0.78rem] text-[var(--muted)] mb-2.5 w-full" />
                    {file && <div className="font-mono text-[0.72rem] text-[#4b8ef0] mb-2.5">↳ {file.name}</div>}
                    <Btn onClick={handleUploadKnowledge} disabled={busy || !file} accent={!busy && !!file}>
                      {busy ? <span className="flex items-center justify-center gap-2"><Spin />Uploading…</span> : 'Upload File'}
                    </Btn>
                  </div>
                  <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-[18px]">
                    <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Markdown Folder</div>
                    <div className="font-mono text-[0.62rem] text-[var(--dim)] mb-1">Chrome / Edge — folder picker</div>
                    <input type="file" {...{ webkitdirectory: '', directory: '' } as any} multiple onChange={e => { if (e.target.files) { const md = Array.from(e.target.files).filter(f => f.name.endsWith('.md')); setFolderFiles(md); md.length ? ok(`${md.length} .md files selected`) : err('No .md files'); } }} className="font-mono text-[0.78rem] text-[var(--muted)] mb-2.5 w-full" />
                    <div className="font-mono text-[0.62rem] text-[var(--dim)] mb-1">All browsers — multi .md select</div>
                    <input type="file" multiple accept=".md" onChange={e => { if (e.target.files) { const md = Array.from(e.target.files); setFolderFiles(md); ok(`${md.length} file(s)`); } }} className="font-mono text-[0.78rem] text-[var(--muted)] mb-2.5 w-full" />
                    {folderFiles.length > 0 && (
                      <div className="font-mono text-[0.7rem] text-[#4b8ef0] bg-[var(--surface2)] rounded-md py-1.5 px-2.5 mb-2.5">
                        {folderFiles.length} files: {folderFiles.slice(0, 4).map(f => f.name).join(', ')}{folderFiles.length > 4 ? ` +${folderFiles.length - 4}` : ''}
                      </div>
                    )}
                    <Btn onClick={handleUploadFolder} disabled={busy || !folderFiles.length} accent={!busy && folderFiles.length > 0}>
                      {busy ? <span className="flex items-center justify-center gap-2"><Spin />Uploading…</span> : `Upload ${folderFiles.length || ''} Files`}
                    </Btn>
                  </div>
                </div>
                <div className="flex flex-col gap-3.5">{renderPipelinePanel()}</div>
              </div>
            )}

            {/* Images / Image Query */}
            {(mode === 'images' || mode === 'image-query') && (
              <div className="grid gap-3.5" style={{ gridTemplateColumns: '300px 1fr' }}>
                <div className="flex flex-col gap-3.5">
                  <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-[18px]">
                    <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Upload Images</div>
                    <input type="file" accept="image/*" multiple onChange={e => { if (e.target.files) setImages(Array.from(e.target.files)); }} className="font-mono text-[0.78rem] text-[var(--muted)] mb-2 w-full" />
                    <div className="font-mono text-[0.62rem] text-[var(--dim)] mb-2.5">Max 20 · 5 MB each</div>
                    <Btn onClick={handleUploadImages} disabled={busy || !images.length} accent={!busy && images.length > 0}>
                      {busy ? <span className="flex items-center justify-center gap-2"><Spin />Uploading…</span> : `Upload ${images.length || ''} Image(s)`}
                    </Btn>
                  </div>
                  {mode === 'image-query' && (
                    <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-[18px]">
                      <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Search by Keyword</div>
                      <input
                        type="text" value={question} onChange={e => setQuestion(e.target.value)}
                        onKeyDown={e => { if (e.key === 'Enter') handleImageSearch(); }}
                        placeholder="dog, sunset, city…"
                        className="bg-[var(--surface)] border border-[var(--border2)] text-[var(--text)] rounded-[10px] px-3.5 py-2.5 text-[0.88rem] outline-none w-full mb-2.5 transition-[border-color] duration-150 focus:border-[#4b8ef0] focus:shadow-[0_0_0_3px_rgba(75,142,240,.09)]"
                      />
                      <Btn onClick={handleImageSearch} disabled={busy || !question.trim()} accent={!busy && !!question.trim()}>
                        {busy ? <span className="flex items-center justify-center gap-2"><Spin />Searching…</span> : 'Search'}
                      </Btn>
                    </div>
                  )}
                </div>
                {retrievedImages.length > 0 && mode === 'image-query' && (
                  <div>
                    <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-3">{retrievedImages.length} results</div>
                    <div className="grid gap-2.5" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(150px,1fr))' }}>
                      {retrievedImages.map(img => (
                        <div key={img.id} onClick={() => setLightboxImg(img.s3Url)} className="rounded-lg overflow-hidden border border-[var(--border2)] cursor-pointer transition-[border-color,transform] duration-150 hover:border-[#4b8ef0] hover:scale-[1.02]">
                          <img src={img.s3Url} alt={img.description || ''} className="w-full h-[90px] object-cover block" />
                          <div className="p-2">
                            {img.score !== undefined && <div className="font-mono text-[0.65rem] text-[#4b8ef0] mb-[3px]">{(img.score * 100).toFixed(1)}%</div>}
                            {img.description && <p className="font-mono text-[0.68rem] text-[var(--muted)] leading-snug m-0">{img.description.slice(0, 60)}{img.description.length > 60 ? '…' : ''}</p>}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* All Images */}
            {mode === 'all-images' && (
              retrievedImages.length > 0 ? (
                <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(195px,1fr))' }}>
                  {retrievedImages.map(img => (
                    <div key={img.id} className="bg-[var(--surface)] border border-[var(--border)] rounded-xl overflow-hidden">
                      <img src={img.s3Url} alt={img.description || ''} className="w-full h-[140px] object-cover block cursor-zoom-in" onClick={() => setLightboxImg(img.s3Url)} />
                      <div className="p-3">
                        {img.description && (
                          <p className="font-mono text-[0.72rem] text-[var(--muted)] leading-relaxed mb-2 overflow-hidden" style={{ display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as any }}>
                            {img.description}
                          </p>
                        )}
                        {img.keywords && img.keywords.length > 0 && (
                          <div className="flex flex-wrap gap-1 mb-2">
                            {img.keywords.slice(0, 4).map((kw, i) => (
                              <span key={i} className="inline-flex items-center gap-1 font-mono text-[0.6rem] tracking-[.05em] px-[7px] py-0.5 rounded border border-[var(--border2)] text-[var(--muted)]">{kw}</span>
                            ))}
                          </div>
                        )}
                        <Btn onClick={() => handleDeleteImage(img.id)} disabled={busy} danger>Delete</Btn>
                      </div>
                    </div>
                  ))}
                </div>
              ) : <div className="text-center font-sans text-[0.88rem] text-[var(--muted)] py-20">No images in store</div>
            )}

            {/* All Documents */}
            {mode === 'all-documents' && (
              allDocuments.length > 0 ? (
                <div className="flex flex-col gap-3.5">
                  {allDocuments.map(doc => (
                    <div key={doc.id} className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-[18px]">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-mono text-[0.62rem] text-[var(--muted)]">
                          {doc.id.slice(0, 12)}…{doc.createdAt && ` · ${new Date(doc.createdAt).toLocaleDateString()}`}{doc.model && ` · ${doc.model}`}
                        </span>
                        <button
                          onClick={() => handleDeleteDoc(doc.id)}
                          disabled={busy}
                          className="font-mono text-[0.7rem] text-[#e87c7c] bg-[rgba(232,124,124,.08)] border border-[rgba(232,124,124,.25)] rounded-md py-0.5 px-2.5 cursor-pointer"
                        >delete</button>
                      </div>
                      <p className="font-mono text-[0.78rem] text-[var(--muted)] leading-[1.7] m-0">
                        {doc.text.slice(0, 300)}{doc.text.length > 300 ? '…' : ''}
                      </p>
                    </div>
                  ))}
                </div>
              ) : <div className="text-center font-sans text-[0.88rem] text-[var(--muted)] py-20">No documents in store</div>
            )}

            {/* Evaluation */}
            {mode === 'evaluation' && (
              <div className="max-w-[700px]">
                <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-[18px]">
                  <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Test Queries — one per line</div>
                  <textarea
                    value={question} onChange={e => setQuestion(e.target.value)} rows={10}
                    className="bg-[var(--surface)] border border-[var(--border2)] text-[var(--text)] rounded-[10px] px-3.5 py-2.5 text-[0.88rem] outline-none w-full mb-2.5 resize-y transition-[border-color] duration-150 leading-[1.7] focus:border-[#4b8ef0] focus:shadow-[0_0_0_3px_rgba(75,142,240,.09)]"
                    placeholder={'What is machine learning?\nHow does RAG work?\nExplain transformers…'}
                  />
                  <Btn onClick={handleEvaluate} disabled={busy || !question.trim()} accent={!busy && !!question.trim()}>
                    {busy ? <span className="flex items-center justify-center gap-2"><Spin />Evaluating…</span> : 'Run Evaluation'}
                  </Btn>
                </div>
                {evalResults && (
                  <div className="bg-[var(--surface)] border border-[var(--border)] rounded-xl p-[18px] mt-3.5">
                    <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2">Results</div>
                    <div className="grid grid-cols-3 gap-2.5 mb-4">
                      {([
                        ['Context Relevance', evalResults.averageMetrics.contextRelevance],
                        ['Faithfulness', evalResults.averageMetrics.answerFaithfulness],
                        ['Answer Relevance', evalResults.averageMetrics.answerRelevance],
                        ['Overall', evalResults.averageMetrics.overall],
                      ] as [string, number][]).map(([label, val]) => (
                        <div key={label} className="bg-[var(--surface2)] border border-[var(--border)] rounded-[10px] p-3.5 text-center">
                          <div className="font-mono text-[0.58rem] text-[var(--dim)] tracking-[.1em] uppercase mb-2">{label}</div>
                          <div
                            className="font-mono text-[1.4rem] font-bold"
                            style={{ color: label === 'Overall' ? 'var(--accent)' : 'var(--muted)' }}
                          >
                            {(val * 100).toFixed(1)}<span className="text-[0.75rem] font-normal">%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                    {evalResults.summary && (
                      <div className="flex gap-5 font-mono text-[0.7rem] text-[var(--dim)]">
                        <span>queries: {evalResults.summary.totalQueries}</span>
                        <span>answered: {evalResults.summary.answeredQueries}</span>
                        {evalResults.summary.avgChunksRetrieved && <span>avg chunks: {evalResults.summary.avgChunksRetrieved.toFixed(1)}</span>}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {generatedImage && (
              <div className="text-center mt-6">
                <div className="font-mono text-[0.6rem] font-semibold tracking-[.12em] uppercase text-[var(--dim)] mb-2.5">Generated Image</div>
                <img src={generatedImage} alt="Generated" className="max-w-full rounded-xl border border-[var(--border)]" />
              </div>
            )}
          </main>
        )}
      </div>
    </>
  );
};

export default RagDemo;